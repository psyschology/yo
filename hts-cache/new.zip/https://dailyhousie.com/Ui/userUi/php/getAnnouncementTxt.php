
Tambola game is legal all over india. Except Assam and Odhisa its fully legal to play. Tambola game is a skill base game unlike tinpatti which is pure game of chance. 
<br><br>
This website is provided by starttambola.com  which is a sub-branch of ONCdigital.in . Remember starttambola.com is a plateform provider and not the owner this website . This game result is 100% legit. To check digital certificate please <a href="checkLegitimacy.php">Click here</a>.
