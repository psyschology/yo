<br />
<b>Warning</b>:  Undefined array key "winType" in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>4</b><br />
<br />
<b>Notice</b>:  fread(): Read of 8192 bytes failed with errno=21 Is a directory in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>164</b><br />
<br />
<b>Warning</b>:  Undefined array key "tno:0" in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>166</b><br />
<br />
<b>Warning</b>:  Trying to access array offset on value of type null in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>166</b><br />
<br />
<b>Warning</b>:  Undefined array key "tno:0" in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>167</b><br />
<br />
<b>Warning</b>:  Trying to access array offset on value of type null in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>167</b><br />
<br />
<b>Warning</b>:  Undefined array key "tno:0" in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>168</b><br />
<br />
<b>Warning</b>:  Trying to access array offset on value of type null in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>168</b><br />
<br />
<b>Fatal error</b>:  Uncaught TypeError: array_merge(): Argument #1 must be of type array, null given in /home/u873236894/domains/dailyhousie.com/public_html/Ui/userUi/php/searchTicketByWinType.php:169
Stack trace:
#0 /home/u873236894/domains/dailyhousie.com/public_html/Ui/userUi/php/searchTicketByWinType.php(169): array_merge()
#1 {main}
  thrown in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/userUi/php/searchTicketByWinType.php</b> on line <b>169</b><br />
