<br />
<b>Warning</b>:  Undefined array key "html1" in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/userUi/php/searchAllTicket.php</b> on line <b>3</b><br />
<br />
<b>Warning</b>:  Undefined array key "html2" in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/userUi/php/searchAllTicket.php</b> on line <b>4</b><br />
<br />
<b>Warning</b>:  Undefined array key "html3" in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/userUi/php/searchAllTicket.php</b> on line <b>5</b><br />
