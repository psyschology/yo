<br />
<b>Warning</b>:  Undefined variable $ticketNum in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/userUi/php/getAgentList.php</b> on line <b>35</b><br />
<br />
<b>Warning</b>:  Undefined array key "tno:" in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/userUi/php/getAgentList.php</b> on line <b>35</b><br />
<br />
<b>Warning</b>:  Trying to access array offset on value of type null in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/userUi/php/getAgentList.php</b> on line <b>35</b><br />
<br />
<b>Warning</b>:  Undefined variable $ticketNum in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/userUi/php/getAgentList.php</b> on line <b>35</b><br />
<br />
<b>Warning</b>:  Undefined array key "tno:" in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/userUi/php/getAgentList.php</b> on line <b>35</b><br />
<br />
<b>Warning</b>:  Trying to access array offset on value of type null in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/userUi/php/getAgentList.php</b> on line <b>35</b><br />
<br />
<b>Warning</b>:  Undefined variable $ticketNum in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/userUi/php/getAgentList.php</b> on line <b>35</b><br />
<br />
<b>Warning</b>:  Undefined array key "tno:" in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/userUi/php/getAgentList.php</b> on line <b>35</b><br />
<br />
<b>Warning</b>:  Trying to access array offset on value of type null in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/userUi/php/getAgentList.php</b> on line <b>35</b><br />
<br />
<b>Warning</b>:  Undefined variable $ticketNum in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/userUi/php/getAgentList.php</b> on line <b>35</b><br />
<br />
<b>Warning</b>:  Undefined array key "tno:" in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/userUi/php/getAgentList.php</b> on line <b>35</b><br />
<br />
<b>Warning</b>:  Trying to access array offset on value of type null in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/userUi/php/getAgentList.php</b> on line <b>35</b><br />
<br />
<b>Warning</b>:  Undefined variable $ticketNum in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/userUi/php/getAgentList.php</b> on line <b>35</b><br />
<br />
<b>Warning</b>:  Undefined array key "tno:" in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/userUi/php/getAgentList.php</b> on line <b>35</b><br />
<br />
<b>Warning</b>:  Trying to access array offset on value of type null in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/userUi/php/getAgentList.php</b> on line <b>35</b><br />
<br />
<b>Warning</b>:  Undefined variable $ticketNum in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/userUi/php/getAgentList.php</b> on line <b>35</b><br />
<br />
<b>Warning</b>:  Undefined array key "tno:" in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/userUi/php/getAgentList.php</b> on line <b>35</b><br />
<br />
<b>Warning</b>:  Trying to access array offset on value of type null in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/userUi/php/getAgentList.php</b> on line <b>35</b><br />
<br />
<b>Warning</b>:  Undefined variable $ticketNum in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/userUi/php/getAgentList.php</b> on line <b>35</b><br />
<br />
<b>Warning</b>:  Undefined array key "tno:" in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/userUi/php/getAgentList.php</b> on line <b>35</b><br />
<br />
<b>Warning</b>:  Trying to access array offset on value of type null in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/userUi/php/getAgentList.php</b> on line <b>35</b><br />
<br />
<b>Warning</b>:  Undefined variable $ticketNum in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/userUi/php/getAgentList.php</b> on line <b>35</b><br />
<br />
<b>Warning</b>:  Undefined array key "tno:" in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/userUi/php/getAgentList.php</b> on line <b>35</b><br />
<br />
<b>Warning</b>:  Trying to access array offset on value of type null in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/userUi/php/getAgentList.php</b> on line <b>35</b><br />
<br />
<b>Warning</b>:  Undefined variable $ticketNum in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/userUi/php/getAgentList.php</b> on line <b>35</b><br />
<br />
<b>Warning</b>:  Undefined array key "tno:" in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/userUi/php/getAgentList.php</b> on line <b>35</b><br />
<br />
<b>Warning</b>:  Trying to access array offset on value of type null in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/userUi/php/getAgentList.php</b> on line <b>35</b><br />
{"data":[{"id":"30_07_2024,03_07_10_PM","name":"yash","totalTicketSold":"0","phone":"+91"}]}