<br />
<b>Warning</b>:  Undefined array key "tno" in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/agentUi/php/getTicketDetail.php</b> on line <b>3</b><br />
<br />
<b>Warning</b>:  Undefined array key "tno:" in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/agentUi/php/getTicketDetail.php</b> on line <b>7</b><br />
<br />
<b>Warning</b>:  Trying to access array offset on value of type null in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/agentUi/php/getTicketDetail.php</b> on line <b>7</b><br />
<br />
<b>Warning</b>:  Undefined array key "tno:" in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/agentUi/php/getTicketDetail.php</b> on line <b>8</b><br />
<br />
<b>Warning</b>:  Trying to access array offset on value of type null in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/agentUi/php/getTicketDetail.php</b> on line <b>8</b><br />
<br />
<b>Warning</b>:  Undefined array key "tno:" in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/agentUi/php/getTicketDetail.php</b> on line <b>9</b><br />
<br />
<b>Warning</b>:  Trying to access array offset on value of type null in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/agentUi/php/getTicketDetail.php</b> on line <b>9</b><br />
<br />
<b>Warning</b>:  Undefined array key "tno:" in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/agentUi/php/getTicketDetail.php</b> on line <b>10</b><br />
<br />
<b>Warning</b>:  Trying to access array offset on value of type null in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/agentUi/php/getTicketDetail.php</b> on line <b>10</b><br />
<br />
<b>Warning</b>:  fopen(../../../agentDb//name.txt): Failed to open stream: No such file or directory in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/agentUi/php/getTicketDetail.php</b> on line <b>16</b><br />
<br />
<b>Fatal error</b>:  Uncaught TypeError: fread(): Argument #1 ($stream) must be of type resource, bool given in /home/u873236894/domains/dailyhousie.com/public_html/Ui/agentUi/php/getTicketDetail.php:16
Stack trace:
#0 /home/u873236894/domains/dailyhousie.com/public_html/Ui/agentUi/php/getTicketDetail.php(16): fread()
#1 {main}
  thrown in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/agentUi/php/getTicketDetail.php</b> on line <b>16</b><br />
