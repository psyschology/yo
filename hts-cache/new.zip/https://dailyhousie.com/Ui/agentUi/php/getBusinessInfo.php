<br />
<b>Warning</b>:  Undefined array key "agentId" in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/agentUi/php/getBusinessInfo.php</b> on line <b>4</b><br />
{"totalTicket":600,"soldTicket":"0","totalHaftsheetBookedTkt":"0","totalFullsheetBookedTkt":"0","ticketLeft":"600","ticketPrice":"300","agentCommission":"50","totalRevenue":"0","totalProfit":"0"}