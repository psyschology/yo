<br />
<b>Warning</b>:  Undefined array key "name" in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/agentUi/php/login.php</b> on line <b>3</b><br />
<br />
<b>Warning</b>:  Undefined array key "pass" in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/agentUi/php/login.php</b> on line <b>4</b><br />
