<br />
<b>Warning</b>:  Undefined array key "key" in <b>/home/u873236894/domains/dailyhousie.com/public_html/Ui/agentUi/php/getSoldTicket.php</b> on line <b>3</b><br />
Session out!