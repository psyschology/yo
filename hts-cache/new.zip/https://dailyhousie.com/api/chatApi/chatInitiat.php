<br />
<b>Warning</b>:  Undefined array key "chatId" in <b>/home/u873236894/domains/dailyhousie.com/public_html/api/chatApi/chatInitiat.php</b> on line <b>4</b><br />
_919