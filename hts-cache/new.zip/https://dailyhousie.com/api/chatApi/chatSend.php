<br />
<b>Warning</b>:  Undefined array key "chatId" in <b>/home/u873236894/domains/dailyhousie.com/public_html/api/chatApi/chatSend.php</b> on line <b>3</b><br />
<br />
<b>Warning</b>:  Undefined array key "msg" in <b>/home/u873236894/domains/dailyhousie.com/public_html/api/chatApi/chatSend.php</b> on line <b>4</b><br />
chat not initiated