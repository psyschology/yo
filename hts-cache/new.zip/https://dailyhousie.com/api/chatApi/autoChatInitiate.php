<br />
<b>Warning</b>:  Undefined array key "chatId" in <b>/home/u873236894/domains/dailyhousie.com/public_html/api/chatApi/autoChatInitiate.php</b> on line <b>3</b><br />
Auto login successfully